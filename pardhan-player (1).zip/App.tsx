import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI } from "@google/genai";
import TitleBar from './components/TitleBar';
import MenuBar from './components/MenuBar';
import VideoDisplay from './components/VideoDisplay';
import Controls from './components/Controls';
import StatusBar from './components/StatusBar';

const App: React.FC = () => {
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [fileName, setFileName] = useState('No file loaded');
  const [videoDimensions, setVideoDimensions] = useState({ width: 0, height: 0 });
  const [isAiSubtitlesEnabled, setIsAiSubtitlesEnabled] = useState(false);
  const [aiSubtitleText, setAiSubtitleText] = useState('');
  const [isLoadingAiSubtitle, setIsLoadingAiSubtitle] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(!!document.fullscreenElement);
  const [showUi, setShowUi] = useState(true);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const appContainerRef = useRef<HTMLDivElement>(null);
  const aiIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const inactivityTimerRef = useRef<NodeJS.Timeout | null>(null);

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setVideoSrc(url);
      setFileName(file.name);
      setIsPlaying(true);
      setAiSubtitleText('');
      if (isAiSubtitlesEnabled) {
        toggleAiSubtitles(true); // restart subtitles for new video
      }
    }
  };

  const openFile = () => {
    fileInputRef.current?.click();
  };

  const handlePlayPause = useCallback(() => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  }, [isPlaying]);

  const handleStop = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
      setIsPlaying(false);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (videoRef.current) {
      const newTime = (Number(e.target.value) / 100) * duration;
      videoRef.current.currentTime = newTime;
      setProgress(Number(e.target.value));
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (videoRef.current) {
      const newVolume = Number(e.target.value);
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
      if (newVolume > 0 && isMuted) {
        setIsMuted(false);
        videoRef.current.muted = false;
      }
    }
  };
  
  const handleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };
  
  const handleFastForward = () => {
    if (videoRef.current) {
        videoRef.current.currentTime = Math.min(videoRef.current.duration, videoRef.current.currentTime + 5);
    }
  };

  const handleFastRewind = () => {
      if (videoRef.current) {
          videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 5);
      }
  };
  
  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
        appContainerRef.current?.requestFullscreen().catch(err => {
          alert(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
        });
    } else {
        document.exitFullscreen();
    }
  };

  const handleClose = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    setVideoSrc(null);
    setFileName('No file loaded');
    setIsPlaying(false);
    setProgress(0);
    setDuration(0);
    setVideoDimensions({ width: 0, height: 0 });
    setAiSubtitleText('');
    if (isAiSubtitlesEnabled) {
      toggleAiSubtitles(false);
    }
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };


  const generateAiSubtitle = useCallback(async (base64ImageData: string) => {
    if (isLoadingAiSubtitle) return;
    setIsLoadingAiSubtitle(true);
    try {
      const imagePart = {
        inlineData: {
          mimeType: 'image/jpeg',
          data: base64ImageData.split(',')[1],
        },
      };
      const textPart = {
        text: 'Briefly describe this scene in one short sentence, as if it were a descriptive subtitle for the hearing impaired.',
      };
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
      });
      setAiSubtitleText(response.text);
    } catch (error) {
      console.error('Error generating AI subtitle:', error);
      setAiSubtitleText('Error generating subtitle.');
      // Stop the feature on error
      toggleAiSubtitles(false);
    } finally {
      setIsLoadingAiSubtitle(false);
    }
  }, [isLoadingAiSubtitle]);

  const toggleAiSubtitles = useCallback((forceState?: boolean) => {
    const newState = forceState ?? !isAiSubtitlesEnabled;
    setIsAiSubtitlesEnabled(newState);
    if (newState && videoSrc) {
        if (aiIntervalRef.current) clearInterval(aiIntervalRef.current);
        aiIntervalRef.current = setInterval(() => {
            if (videoRef.current && isPlaying) {
                const video = videoRef.current;
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                    generateAiSubtitle(dataUrl);
                }
            }
        }, 7000); // every 7 seconds
    } else {
        if (aiIntervalRef.current) clearInterval(aiIntervalRef.current);
        aiIntervalRef.current = null;
        setAiSubtitleText('');
    }
  }, [isAiSubtitlesEnabled, videoSrc, isPlaying, generateAiSubtitle]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateProgress = () => {
      setProgress((video.currentTime / video.duration) * 100);
    };

    const updateDuration = () => {
      setDuration(video.duration);
      setVideoDimensions({ width: video.videoWidth, height: video.videoHeight });
    };

    const handleEnd = () => setIsPlaying(false);
    
    video.addEventListener('timeupdate', updateProgress);
    video.addEventListener('loadedmetadata', updateDuration);
    video.addEventListener('ended', handleEnd);

    if (isPlaying) {
      video.play().catch(e => console.error("Autoplay failed:", e));
    } else {
      video.pause();
    }

    return () => {
      video.removeEventListener('timeupdate', updateProgress);
      video.removeEventListener('loadedmetadata', updateDuration);
      video.removeEventListener('ended', handleEnd);
      if (aiIntervalRef.current) {
        clearInterval(aiIntervalRef.current);
      }
    };
  }, [videoSrc, isPlaying]);
  
  useEffect(() => {
    const handleFullScreenChange = () => {
      const isCurrentlyFullScreen = !!document.fullscreenElement;
      setIsFullScreen(isCurrentlyFullScreen);
      if (!isCurrentlyFullScreen) {
        setShowUi(true); // Always show UI when exiting fullscreen
        if (inactivityTimerRef.current) {
          clearTimeout(inactivityTimerRef.current);
        }
      }
    };
    document.addEventListener('fullscreenchange', handleFullScreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullScreenChange);
  }, []);
  
  const handleMouseMove = useCallback(() => {
      if (isFullScreen) {
          setShowUi(true);
          if (inactivityTimerRef.current) {
              clearTimeout(inactivityTimerRef.current);
          }
          inactivityTimerRef.current = setTimeout(() => {
              setShowUi(false);
          }, 3000);
      } else {
        setShowUi(true); // Always show UI when not in fullscreen
      }
  }, [isFullScreen]);

  const uiVisible = !isFullScreen || showUi;

  return (
    <div 
        ref={appContainerRef} 
        className="relative w-full h-screen bg-[#21252B] flex flex-col font-sans text-sm antialiased overflow-hidden select-none"
        onMouseMove={handleMouseMove}
    >
      <div className="relative flex-grow w-full h-full">
        <VideoDisplay 
          videoSrc={videoSrc} 
          videoRef={videoRef} 
          onDoubleClick={toggleFullScreen}
          aiSubtitleText={aiSubtitleText}
          isLoadingAiSubtitle={isLoadingAiSubtitle}
          isFullScreen={isFullScreen}
          showUi={showUi}
        />
      </div>

      {/* UI Overlay */}
      <div className={`absolute inset-0 flex flex-col pointer-events-none transition-opacity duration-300 ${uiVisible ? 'opacity-100' : 'opacity-0'}`}>
        <div className="pointer-events-auto">
            <TitleBar title={`PARDHAN Player - ${fileName}`} onMaximize={toggleFullScreen} onClose={handleClose} />
            <MenuBar onOpenFile={openFile} onToggleAiSubtitles={toggleAiSubtitles} isAiSubtitlesEnabled={isAiSubtitlesEnabled}/>
        </div>

        <div className="flex-grow" onClick={videoSrc ? handlePlayPause : undefined} /> {/* Spacer / Click-to-play area */}
        
        <div className="pointer-events-auto">
            <div className="bg-[#282C34] p-1 border-t border-gray-700">
                <Controls
                    isPlaying={isPlaying}
                    progress={progress}
                    duration={duration}
                    volume={volume}
                    isMuted={isMuted}
                    currentTime={videoRef.current?.currentTime || 0}
                    onPlayPause={handlePlayPause}
                    onStop={handleStop}
                    onSeek={handleSeek}
                    onVolumeChange={handleVolumeChange}
                    onMute={handleMute}
                    onFastForward={handleFastForward}
                    onFastRewind={handleFastRewind}
                    onOpenFile={openFile}
                    onToggleFullScreen={toggleFullScreen}
                />
            </div>
            <StatusBar
                isPlaying={isPlaying}
                dimensions={videoDimensions}
                videoSrc={videoSrc}
            />
        </div>
      </div>

      <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="video/*"
      />
    </div>
  );
};

export default App;
