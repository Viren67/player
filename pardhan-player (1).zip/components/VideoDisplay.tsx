import React from 'react';
import { Logo } from './Logo';

interface VideoDisplayProps {
  videoSrc: string | null;
  videoRef: React.RefObject<HTMLVideoElement>;
  onDoubleClick: () => void;
  aiSubtitleText: string;
  isLoadingAiSubtitle: boolean;
  isFullScreen: boolean;
  showUi: boolean;
}

const VideoDisplay: React.FC<VideoDisplayProps> = ({ videoSrc, videoRef, onDoubleClick, aiSubtitleText, isLoadingAiSubtitle, isFullScreen, showUi }) => {
  const shouldHideCursor = isFullScreen && !showUi;
  return (
    <div className={`relative w-full h-full bg-black flex items-center justify-center overflow-hidden ${shouldHideCursor ? 'cursor-none' : ''}`} onDoubleClick={onDoubleClick}>
      {videoSrc ? (
        <video ref={videoRef} src={videoSrc} className="w-full h-full object-contain" />
      ) : (
        <Logo />
      )}
       {(aiSubtitleText || isLoadingAiSubtitle) && videoSrc && (
        <div className="absolute bottom-5 left-1/2 -translate-x-1/2 w-3/4 p-2 bg-black bg-opacity-60 text-white text-center text-sm md:text-base rounded-md pointer-events-none transition-opacity duration-300">
          {isLoadingAiSubtitle ? 
            <div className="flex justify-center items-center space-x-2">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-white rounded-full animate-pulse [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            </div>
            : aiSubtitleText}
        </div>
      )}
    </div>
  );
};

export default VideoDisplay;
