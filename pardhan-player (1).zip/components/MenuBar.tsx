import React, { useState, useRef, useEffect, useCallback } from 'react';
import { AiIcon } from './Icons';

interface MenuBarProps {
  onOpenFile: () => void;
  onToggleAiSubtitles: () => void;
  isAiSubtitlesEnabled: boolean;
}

const Menu: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleMouseEnter = () => setIsOpen(true);
  const handleMouseLeave = () => setIsOpen(false);

  return (
    <div ref={menuRef} onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave} className="relative">
      <div
        className={`px-3 py-0.5 rounded-sm cursor-pointer ${isOpen ? 'bg-blue-600 text-white' : 'hover:bg-gray-600'}`}
      >
        {label}
      </div>
      {isOpen && (
        <div className="absolute left-0 top-full mt-0 w-60 bg-[#282C34] border border-gray-700 shadow-lg rounded-sm py-1 z-20">
          {children}
        </div>
      )}
    </div>
  );
};

const MenuItem: React.FC<{ onClick?: () => void; children: React.ReactNode; shortcut?: string; disabled?: boolean; checked?: boolean; icon?: React.ReactNode; }> = 
({ onClick, children, shortcut, disabled = false, checked = false, icon }) => {
  return (
    <div
      onClick={!disabled ? onClick : undefined}
      className={`px-3 py-1 flex justify-between items-center ${
        disabled
          ? 'text-gray-500 cursor-default'
          : 'text-gray-300 hover:bg-blue-600 hover:text-white cursor-pointer'
      }`}
    >
      <div className="flex items-center space-x-2">
        {icon ? icon : <span className="w-4">{checked && '✔'}</span>}
        <span>{children}</span>
      </div>
      {shortcut && <span className="text-gray-400">{shortcut}</span>}
    </div>
  );
};


const MenuBar: React.FC<MenuBarProps> = ({ onOpenFile, onToggleAiSubtitles, isAiSubtitlesEnabled }) => {
  return (
    <div className="h-6 bg-[#282C34] flex items-center px-2 text-gray-300 text-xs border-b border-gray-700">
      <Menu label="File">
        <MenuItem onClick={onOpenFile} shortcut="Ctrl+O">Open File...</MenuItem>
        <MenuItem disabled>Open Disc...</MenuItem>
        <MenuItem disabled>Recent Files</MenuItem>
        <hr className="border-t border-gray-600 my-1" />
        <MenuItem disabled>Save Image...</MenuItem>
        <MenuItem disabled>Save Subtitles...</MenuItem>
        <hr className="border-t border-gray-600 my-1" />
        <MenuItem disabled>Properties</MenuItem>
        <MenuItem disabled>Exit</MenuItem>
      </Menu>
      <Menu label="View">
        <MenuItem disabled>Playlist</MenuItem>
        <MenuItem disabled>Subtitles</MenuItem>
        <hr className="border-t border-gray-600 my-1" />
        <MenuItem disabled>Renderer Settings</MenuItem>
        <MenuItem disabled checked>Statistics</MenuItem>
      </Menu>
      <Menu label="Play">
        <MenuItem disabled>Play/Pause</MenuItem>
        <MenuItem disabled>Stop</MenuItem>
        <hr className="border-t border-gray-600 my-1" />
        <MenuItem disabled>Increase Rate</MenuItem>
        <MenuItem disabled>Decrease Rate</MenuItem>
      </Menu>
       <Menu label="Tools">
        <MenuItem onClick={onToggleAiSubtitles} checked={isAiSubtitlesEnabled} icon={<AiIcon />}>AI Vision Subtitles</MenuItem>
      </Menu>
      <Menu label="Help">
        <MenuItem disabled>About</MenuItem>
      </Menu>
    </div>
  );
};

export default MenuBar;
