import React from 'react';
import { MuteIcon, VolumeIcon } from './Icons';

interface VolumeControlProps {
  volume: number;
  isMuted: boolean;
  onVolumeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onMute: () => void;
}

const VolumeControl: React.FC<VolumeControlProps> = ({ volume, isMuted, onVolumeChange, onMute }) => {
  const displayVolume = isMuted ? 0 : volume;
  const background = `linear-gradient(to right, #2563EB ${displayVolume * 100}%, #4A5568 ${displayVolume * 100}%)`;

  return (
    <div className="flex items-center space-x-1">
      <button onClick={onMute} className="p-1 text-gray-300 hover:bg-gray-600 rounded">
        {isMuted || volume === 0 ? <MuteIcon /> : <VolumeIcon />}
      </button>
      <input
        type="range"
        min="0"
        max="1"
        step="0.01"
        value={displayVolume}
        onChange={onVolumeChange}
        className="w-20 h-1.5 rounded-lg appearance-none cursor-pointer"
        style={{ background }}
      />
    </div>
  );
};

export default VolumeControl;
