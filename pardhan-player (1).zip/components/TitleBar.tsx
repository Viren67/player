import React from 'react';
import { MPCIcon, MinimizeIcon, MaximizeIcon, CloseIcon } from './Icons';

interface TitleBarProps {
  title: string;
  onMaximize: () => void;
  onClose: () => void;
}

const TitleBar: React.FC<TitleBarProps> = ({ title, onMaximize, onClose }) => {
  return (
    <div className="h-7 bg-gradient-to-b from-gray-700 to-gray-800 flex items-center justify-between pl-2 pr-1 border-b border-gray-900 shadow-md">
      <div className="flex items-center">
        <MPCIcon className="w-4 h-4 mr-2" />
        <span className="text-gray-200 text-xs font-semibold select-none">{title}</span>
      </div>
      <div className="flex items-center space-x-1">
        <button disabled className="w-6 h-5 flex items-center justify-center border border-gray-600 bg-gray-700 rounded-sm text-white opacity-50 cursor-not-allowed">
          <MinimizeIcon />
        </button>
        <button onClick={onMaximize} className="w-6 h-5 flex items-center justify-center border border-gray-600 bg-gray-700 hover:bg-gray-500 rounded-sm text-white">
          <MaximizeIcon />
        </button>
        <button onClick={onClose} className="w-6 h-5 flex items-center justify-center border border-red-600 bg-red-700 hover:bg-red-500 rounded-sm text-white">
          <CloseIcon />
        </button>
      </div>
    </div>
  );
};

export default TitleBar;
