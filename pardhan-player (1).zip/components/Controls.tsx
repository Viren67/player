import React from 'react';
import { PlayIcon, PauseIcon, StopIcon, FrameStepBackIcon, FastRewindIcon, FastForwardIcon, FrameStepForwardIcon, OpenFileIcon, MuteIcon, VolumeIcon, FullscreenIcon } from './Icons';
import SeekBar from './SeekBar';
import VolumeControl from './VolumeControl';

interface ControlsProps {
  isPlaying: boolean;
  progress: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  currentTime: number;
  onPlayPause: () => void;
  onStop: () => void;
  onSeek: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onVolumeChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onMute: () => void;
  onFastForward: () => void;
  onFastRewind: () => void;
  onOpenFile: () => void;
  onToggleFullScreen: () => void;
}

const ControlButton: React.FC<{ onClick?: () => void, children: React.ReactNode, disabled?: boolean }> = ({ onClick, children, disabled = false }) => (
    <button onClick={onClick} disabled={disabled} className="p-1 text-gray-300 enabled:hover:bg-gray-600 rounded disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
        {children}
    </button>
);

const Controls: React.FC<ControlsProps> = ({
  isPlaying,
  progress,
  duration,
  volume,
  isMuted,
  currentTime,
  onPlayPause,
  onStop,
  onSeek,
  onVolumeChange,
  onMute,
  onFastForward,
  onFastRewind,
  onOpenFile,
  onToggleFullScreen
}) => {
  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds) || timeInSeconds === 0) return '00:00';
    const hours = Math.floor(timeInSeconds / 3600);
    const minutes = Math.floor((timeInSeconds % 3600) / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    
    const parts = [];
    if (hours > 0) parts.push(String(hours).padStart(2, '0'));
    parts.push(String(minutes).padStart(2, '0'));
    parts.push(String(seconds).padStart(2, '0'));
    
    return parts.join(':');
  };

  return (
    <div className="flex flex-col space-y-1">
        <SeekBar progress={progress} duration={duration} onSeek={onSeek} />
        <div className="flex items-center justify-between px-2">
            <div className="flex items-center space-x-1">
                <ControlButton onClick={onPlayPause}>
                    {isPlaying ? <PauseIcon /> : <PlayIcon />}
                </ControlButton>
                <ControlButton onClick={onStop}><StopIcon /></ControlButton>
                <ControlButton disabled><FrameStepBackIcon /></ControlButton>
                <ControlButton onClick={onFastRewind}><FastRewindIcon /></ControlButton>
                <ControlButton onClick={onFastForward}><FastForwardIcon /></ControlButton>
                <ControlButton disabled><FrameStepForwardIcon /></ControlButton>
                <ControlButton onClick={onOpenFile}><OpenFileIcon /></ControlButton>
            </div>
            <div className="text-xs text-gray-400 font-mono">
                {formatTime(currentTime)} / {formatTime(duration)}
            </div>
            <div className="flex items-center space-x-2">
               <VolumeControl volume={volume} isMuted={isMuted} onVolumeChange={onVolumeChange} onMute={onMute}/>
               <ControlButton onClick={onToggleFullScreen}><FullscreenIcon /></ControlButton>
            </div>
        </div>
    </div>
  );
};

export default Controls;
