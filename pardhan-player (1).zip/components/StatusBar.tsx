import React from 'react';

interface StatusBarProps {
    isPlaying: boolean;
    dimensions: { width: number, height: number };
    videoSrc: string | null;
}

const StatusBar: React.FC<StatusBarProps> = ({ isPlaying, dimensions, videoSrc }) => {
    const statusText = videoSrc ? (isPlaying ? 'Playing' : 'Paused') : 'Ready';
    const dimensionText = videoSrc ? `${dimensions.width}x${dimensions.height}` : '';

    return (
        <div className="h-6 bg-[#282C34] flex items-center justify-between px-3 text-xs text-gray-400 border-t border-gray-700">
            <span>{statusText}</span>
            <span>{dimensionText}</span>
        </div>
    );
};

export default StatusBar;
