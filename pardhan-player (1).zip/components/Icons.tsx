import React from 'react';

// FIX: Update SVGWrapper to accept all SVG props to allow for customization like in AiIcon.
const SVGWrapper: React.FC<React.SVGProps<SVGSVGElement>> = ({ children, className, viewBox = "0 0 24 24", ...props }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className || "w-5 h-5"} viewBox={viewBox} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
        {children}
    </svg>
);

export const PlayIcon: React.FC = () => <SVGWrapper><polygon points="5 3 19 12 5 21 5 3"></polygon></SVGWrapper>;
export const PauseIcon: React.FC = () => <SVGWrapper><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></SVGWrapper>;
export const StopIcon: React.FC = () => <SVGWrapper><rect x="3" y="3" width="18" height="18"></rect></SVGWrapper>;
export const FastRewindIcon: React.FC = () => <SVGWrapper><polygon points="11 19 2 12 11 5 11 19"></polygon><polygon points="22 19 13 12 22 5 22 19"></polygon></SVGWrapper>;
export const FastForwardIcon: React.FC = () => <SVGWrapper><polygon points="13 19 22 12 13 5 13 19"></polygon><polygon points="2 19 11 12 2 5 2 19"></polygon></SVGWrapper>;
export const FrameStepBackIcon: React.FC = () => <SVGWrapper><path d="M11 17l-5-5 5-5M18 17l-5-5 5-5"></path></SVGWrapper>;
export const FrameStepForwardIcon: React.FC = () => <SVGWrapper><path d="M13 17l5-5-5-5M6 17l5-5-5-5"></path></SVGWrapper>;
export const OpenFileIcon: React.FC = () => <SVGWrapper><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></SVGWrapper>;
export const VolumeIcon: React.FC = () => <SVGWrapper><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path></SVGWrapper>;
export const MuteIcon: React.FC = () => <SVGWrapper><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></SVGWrapper>;
export const FullscreenIcon: React.FC = () => <SVGWrapper><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></SVGWrapper>;
export const AiIcon: React.FC = () => <SVGWrapper className="w-4 h-4" viewBox="0 0 20 20" strokeWidth="1.5" fill="currentColor"><path fillRule="evenodd" d="M10 2.5a.75.75 0 01.75.75v.255a.25.25 0 00.5 0V3.25a.75.75 0 011.5 0v.255a.25.25 0 00.5 0V3.25a.75.75 0 011.5 0v.53a2.499 2.499 0 011.233 4.259 2.5 2.5 0 010 4.422 2.499 2.499 0 01-1.233 4.259v.53a.75.75 0 01-1.5 0v-.255a.25.25 0 00-.5 0v.255a.75.75 0 01-1.5 0v-.255a.25.25 0 00-.5 0v.255a.75.75 0 01-1.5 0v-.53a2.499 2.499 0 01-1.233-4.259 2.5 2.5 0 010-4.422A2.499 2.499 0 014.25 8.31V7.78a.75.75 0 011.5 0v.255a.25.25 0 00.5 0V7.03a.75.75 0 011.5 0v.255a.25.25 0 00.5 0V7.03a.75.75 0 011.5 0v.53A2.5 2.5 0 0110 10a2.5 2.5 0 01-1.22-4.665.75.75 0 01.52-1.396A1 1 0 0010 4.5a1 1 0 00.75-1.654V2.5z" clipRule="evenodd" /></SVGWrapper>


export const MPCIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" fill="white">
        <path d="M18 6h-4v20h4z"></path>
        <path d="M24 10h-4v16h4zM12 14h-4v12h4z"></path>
        <path d="M30 18h-4v8h4zM6 22H2v4h4z"></path>
    </svg>
);

export const MinimizeIcon: React.FC = () => <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 16 16" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M14 8H2V7h12v1z"></path></svg>;
export const MaximizeIcon: React.FC = () => <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 16 16" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M1.5 1h13l-.001.5v13l-.5.5h-13l-.5-.5v-13l.5-.5zM2 2v12h12V2H2z"></path></svg>;
export const CloseIcon: React.FC = () => <svg stroke="currentColor" fill="currentColor" strokeWidth="0" viewBox="0 0 16 16" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.75.75 0 1 1 1.06 1.06L9.06 8l3.22 3.22a.75.75 0 1 1-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 0 1-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06z"></path></svg>;
