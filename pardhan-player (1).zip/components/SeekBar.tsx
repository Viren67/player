import React from 'react';

interface SeekBarProps {
  progress: number;
  duration: number;
  onSeek: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const SeekBar: React.FC<SeekBarProps> = ({ progress, duration, onSeek }) => {
  const background = `linear-gradient(to right, #2563EB ${progress}%, #4A5568 ${progress}%)`;

  return (
    <div className="flex items-center w-full px-2">
      <input
        type="range"
        min="0"
        max="100"
        step="0.1"
        value={isNaN(progress) ? 0 : progress}
        onChange={onSeek}
        disabled={duration === 0}
        className="w-full h-1.5 rounded-lg appearance-none cursor-pointer"
        style={{ background: duration > 0 ? background : '#4A5568' }}
      />
    </div>
  );
};

export default SeekBar;
