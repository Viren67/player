import React from 'react';

export const Logo: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center text-center">
            <div className="relative flex items-end h-24 space-x-2">
                <div className="w-5 h-8 bg-gray-600 rounded-sm"></div>
                <div className="w-5 h-12 bg-gray-600 rounded-sm"></div>
                <div className="w-5 h-16 bg-gray-600 rounded-sm"></div>
                <div className="w-5 h-20 bg-gray-600 rounded-sm"></div>
                <div className="w-5 h-24 bg-blue-600 rounded-sm"></div>
                <div className="w-5 h-20 bg-gray-600 rounded-sm"></div>
                <div className="w-5 h-16 bg-gray-600 rounded-sm"></div>
                <div className="absolute top-4 -right-10 transform -rotate-45 text-gray-400 text-xs font-bold tracking-wider">
                    <span className="bg-black px-1">AI</span>
                    <span className="bg-black px-1 ml-1">EDITION</span>
                </div>
            </div>
            <div className="mt-6 text-gray-400">
                <p className="text-xl tracking-[0.3em]">PARDHAN PLAYER</p>
            </div>
        </div>
    );
};
